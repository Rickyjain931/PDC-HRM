import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  username: string = '';
  email: string = '';
  password: string = '';

  onSubmit() {
    console.log('Username:', this.username);
    console.log('Email:', this.email);
    console.log('Password:', this.password);
    alert(`Signup Successful!\nUsername: ${this.username}\nEmail: ${this.email}`);
    
    // Clear the form fields after submission
    this.username = '';
    this.email = '';
    this.password = '';
  }
}
